.. PyModbus documentation master file, created by
   sphinx-quickstart on Tue Apr 14 19:11:16 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyModbus's documentation!
====================================

Contents:

.. toctree::
   :maxdepth: 2

   examples/index.rst
   library/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

