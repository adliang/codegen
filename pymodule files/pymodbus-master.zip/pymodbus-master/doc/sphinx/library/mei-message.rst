:mod:`mei_message` --- MEI Modbus Messages
============================================================

.. module:: mei_message
   :synopsis: MEI Modbus Messages

.. moduleauthor:: Galen Collins <bashwork@gmail.com>
.. sectionauthor:: Galen Collins <bashwork@gmail.com>

API Documentation
-------------------

.. automodule:: pymodbus.mei_message

.. autoclass:: ReadDeviceInformationRequest
   :members:

.. autoclass:: ReadDeviceInformationResponse
   :members:
