==================================================
Changing Default Framers
==================================================

.. literalinclude:: ../../../examples/common/changing-framers.py

