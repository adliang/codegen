==================================================
Modbus Simulator Example
==================================================

.. literalinclude:: ../../../examples/contrib/modbus-simulator.py
