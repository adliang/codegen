==================================================
Remote Single Server Context
==================================================

.. literalinclude:: ../../../examples/contrib/remote_server_context.py

