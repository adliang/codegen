==================================================
Redis Datastore Example
==================================================

.. literalinclude:: ../../../examples/contrib/redis-datastore.py

