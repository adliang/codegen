==================================================
Database Datastore Example
==================================================

.. literalinclude:: ../../../examples/contrib/database-datastore.py

