ctemplate-python
================

This is a python port of an excellent C Template Library 1.0 by Stephen C. Losen (http://libctemplate.sourceforge.net). Distributed under GPL. To install type sudo python setup.py install. For usage case, see useTemplate.py.

Why should you use it?

1. It is superfast and solid, written in pure c. It outpaces all python-based competition.
2. It is really easy to use - has only one function to call and fits comfortably in one .h file and two .c files!
3. Its syntax reasembles HTML and is easy to learn. It has only three sigificant 'tags': loop tag, variable substitution tag and conditional tag.

See original documentation for explanations of usage.

Send me an email if you see it fit:  marek.lipert at gmail.com
